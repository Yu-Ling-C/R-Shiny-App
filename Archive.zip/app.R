library(tidyverse)        # Just to be sure it's the first thing that is done...
library(shiny)
library(shinydashboard)
library(DT)
library(plotly)
library(dplyr)

load("stroke.RData")

ui <- dashboardPage(                                                   # FULL PAGE: don't touch!
  dashboardHeader(title = "Cause of Stroke Dashboard",
                  tags$li(
                    class = "dropdown",
                    tags$a(
                      href = "https://www.linkedin.com/in/yu-ling-shereen-chi/",
                      span(icon("linkedin")),
                      "LinkedIn",
                      target = "_blank"
                    )
                  ),
                  tags$li(
                    class = "dropdown",
                    tags$a(
                      href = "https://github.com/Yu-Ling-C",
                      span(icon("github")),
                      "GitHub",
                      target = "_blank"
                    ))),       # Header zone
  
  dashboardSidebar(sliderInput("avg_glucose_level", h4("AvgGlucoseLevel"),              
                               min = 50, max = 275,                      
                               value = c(50, 275), step = 5, sep = ""),
                   sliderInput("bmi", h4("BMI"),                
                               min = 10, max = 100,
                               value = c(10,100), step = 1, sep = ""),
                   radioButtons("gender", "Select Gender:", c("All", "Male", "Female"), 
                                selected = "All")
                   
  ),        
  dashboardBody(
    tabBox(
      title = "Results", height = "920px", width = "500px",
      tabPanel("WELCOME",
               fluidRow(column(6,h3("HI THERE!"),
                               h4("Here's a quick overview of the dataset:", style = "margin-bottom: 30px;"),
                               h4("Source"),
                               p("The dataset 'healthcare-dataset-stroke-data' was downloaded from Kaggle, one of the most used platform to find open source datasets.", style = "margin-bottom: 30px;"),
                               h4("Context"),
                               p("The dataset selected integrates different factors that might be correlated to the occurrence of stroke.", style = "margin-bottom: 30px;"),
                               h4("Size"),
                               p("The dataset originally consisted of 12 columns and 5110 rows. After cleaning, it remains 11 columns and 4909 rows.", style = "margin-bottom: 30px;"),
                               h4("Variables"),
                               p("There are 11 variables which are column names.", style = "margin-bottom: 30px;"),
                               h4("Variable types"),
                               p("There are 2 types of variables in the dataset: double <dbl> and character <chr>, among which are 3 doubles and 8 characters. Doubles represent numeric values that contain both integers and floats, while characters here stand for categorical variables.")
               ),
               column(6,h3("WHY THIS DATASET?", style = "margin-bottom: 30px;"),
                      h4("Interests in health-related topics"),
                      p("My interests in health-related subjects were developed early in my childhood thanks to my mom who pursues her career at a pharmaceutical company. She would share with me and my brother various terminologies and knowledge in the medical field. Consequently, every time I encounter a new medical term or suffer from any unknown symptoms, I look them up online and discuss with my mom when she's around.", style = "margin-bottom: 30px;"),
                      h4("Trend of having stroke at younger ages"),
                      p("It is reported that stroke has become more and more common among younger generations compared with their forebears at the same age. In addition, some of my relatives or acquaintances suffer from stroke despite their healthy lifestyle. Such phenomenon has aroused my curiosity about the causes of the disease.", style = "margin-bottom: 30px;"),
                      h4("Expected powerful testimonies"),
                      p("The analysis results might provide supporting evidence of correlated factors that cause stroke and thus help raise awareness of its danger as well as promote precautions against the disease. Therefore, our users will be able to predict their probability of having a stroke based on the factors (age, smoking status, etc.) in the dataset, and receive useful recommendations on reducing the risks of having a stroke.", style = "margin-bottom: 30px;")))
      ),
      
      tabPanel("SCATTER PLOT",fluidRow(
        column(12, plotlyOutput("plot")),
        column(6, 
               h3("SOME FACTS...", style = "margin-bottom: 15px;"),
               h4("About stroke"),
               p("1. According to World Health Organization (WHO), stroke is globally the second leading cause of death and the third leading cause of disability.", style = "margin-bottom: 10px;"),
               p("2. As pointed out by the Centers for Disease Control and Prevention (CDC), more than 795,000 people in the United States have a stroke every year.", style = "margin-bottom: 10px;"),
               p("3. Indicated in an article published by Sutter Health, about 70,000 Americans under age 45 have strokes every year. About 10 to 15 percent of strokes occur in children and adults under age 45, and that number is rising.", style = "margin-bottom: 10px;"),
               h4("About Glucose Level"),
               p("Normal fasting blood glucose level should, according to WHO, be between 70 mg/dL and 100 mg/dL; those whose fasting blood glucose is between 100 and 125 are suggested to make changes in lifestyle or regularly monitor their blood glucose level; diabetes is diagnosed when fasting blood glucose is 126 mg/dL or higher on two separate tests.", style = "margin-bottom: 10px;"),
               h4("About BMI"),
               p("Body mass index (BMI) is categorized as followed:"), 
               p("Below 18.5: Underweight; 18.5–24.9: Normal weight; 25.0–29.9: Pre-obesity; 30.0–34.9: Obesity class I; 35.0–39.9: Obesity class II; Above 40: Obesity class III.")
        ),
        column(6, 
               h3("OBSERVATIONS FROM THE PLOT"),
               p("When adding 2 variables, average glucose level and BMI, to the scatter plot, we can observe that there is no significant correlation between them."),
               br(),
               p("However, when looking closely at them respectively, we can observe some interesting phenomena in the distribution of both variables. In terms of average glucose level, it comes with evidence that those who have higher average glucose level bear higher probability of experiencing a stroke. The percetage of people having a stroke with an average glucose level over 125 is 9.31%, while among those whose average glucose level is normal, only 3.07% of them have a stroke.
                   "),
               br(),
               p("On the other hand, BMI does have some direct impact on the occurrence of strokes: the percentage of people with normal BMI having a stroke (2.28%) is lower than that of those whose BMI is over 25 (5.18%). That is to say, it is proved that people whose BMI is under 25 are less likely to have a stroke than those with pre-obesity or obesity.")
        ))),
      
      
      
      tabPanel("DATASET",
               DT::dataTableOutput("table")
      ),
      tabPanel("BOX",
               valueBoxOutput("box1", width = 6),
               valueBoxOutput("box2", width = 6),
               valueBoxOutput("box3", width = 6),
               valueBoxOutput("box4", width = 6),
               fluidRow(column(6, plotOutput("plot1")),
                        (column(6, plotOutput("plot2"))
                        )
               )
      )
    )
  )
)






server <- function(input, output) {
  # Define reactive data
  data <- reactive({
    stroke %>% 
      filter(avg_glucose_level >= input$avg_glucose_level[1],
             avg_glucose_level <= input$avg_glucose_level[2],
             bmi >= input$bmi[1],
             bmi <= input$bmi[2])
  })
  
  # Define reactive filtered data based on selected gender
  filtered_data <- reactive({
    if (input$gender == "All") {
      stroke
    } else {
      subset(stroke, gender == input$gender)
    }
  })
  
  
  # Define reactive data filtered by gender and glucose/BMI values
  filtered_data_all <- reactive({
    data() %>%
      filter(gender %in% unique(filtered_data()$gender)) %>%
      filter(avg_glucose_level >= input$avg_glucose_level[1],
             avg_glucose_level <= input$avg_glucose_level[2],
             bmi >= input$bmi[1],
             bmi <= input$bmi[2])
  })
  
  # Define the output for the table
  output$table <- DT::renderDataTable({
    filtered_data_all() %>%
      select(-work_type, residence_type)
  })
  
  # Define a reactive plot based on the filtered data and selected gender
  output$plot <- renderPlotly({
    plot_ly(filtered_data_all(), x = ~bmi, y = ~avg_glucose_level, color = ~stroke, colors = 
              c("lightblue", "red"), label=stroke,
            type = "scatter", mode = "markers", marker = list(size = 5)) %>%
      layout(xaxis = list(title = "BMI"),
             yaxis = list(title = "Avg Glucose Level"),
             legend = list(title = "stroke"),
             title = "Relationship among BMI, Avg Glucose Level, and Stroke")
  })
  
  # Define the value boxes
  output$box1 <- renderValueBox({
    valueBox(
      value = filtered_data_all() %>% pull(bmi) %>% mean() %>% round(1),
      subtitle = "AVG BMI", 
      icon = icon("weight", lib = "font-awesome"),
      color = "teal"
    )
  })
  
  output$box2 <- renderValueBox({
    valueBox(
      value = filtered_data_all() %>% pull(age) %>% mean() %>% round(1),
      subtitle = "AVG AGE",
      icon = icon("glasses", lib = "font-awesome"),
      color = "maroon"
    )
  })
  
  output$box3 <- renderValueBox({
    valueBox(
      value = filtered_data_all() %>% pull(avg_glucose_level) %>% mean() %>% round(1),
      subtitle = "AVG GLUCOSE LEVEL",
      icon = icon("cake", lib = "font-awesome"),
      color = "green"
    )
  })
  output$box4 <- renderValueBox({
    heart_dis_count <- filtered_data_all() %>% filter(heart_disease == "Yes") %>% nrow()
    total_count <- filtered_data_all() %>% nrow()
    heart_dis_percent <- round(heart_dis_count/total_count * 100, 1)
    valueBox(
      value = heart_dis_percent,
      subtitle = "HEART DISEASE %",
      icon = icon("heart", lib = "font-awesome"),
      color = "orange"
    )
  })
  
  
  output$plot1 <- renderPlot({
    # Create a table of counts and percentages by smoking status and stroke
    count_table <- stroke %>% 
      group_by(smoking_status, stroke) %>% 
      summarize(count = n()) %>% 
      mutate(percent = count / sum(count) * 100)
    
    # Create the ggplot bar plot with fill color and percentage labels
    ggplot(count_table, aes(x = smoking_status, y = count, fill = stroke)) + 
      geom_bar(stat = "identity") + 
      scale_fill_brewer(palette = "RdBu") + 
      theme_minimal() +
      # Add percentage labels with formatted text
      geom_text(aes(label = paste0(round(percent, 1), "%")), 
                position = position_stack(vjust = 0.5)) +
      # Format y-axis as percentages
      scale_y_continuous(breaks=c(500, 1000, 1500, 2000)) +
      ggtitle("Impact of Smoking Status on Stroke")+
      theme(plot.title = element_text(size = 18, hjust = 0.5))
  })
  
  
  
  
  
  
  
  
  output$plot2 <- renderPlot({
    ggplot(data = filtered_data_all(), aes(x = gender, fill = "blue")) +
      geom_bar() +
      geom_text(stat = "count", aes(label = ..count..), vjust = -0.5)+
      theme_minimal() +
      labs(x = "Gender", y = "Count")+
      ggtitle("Gender Distribution")+
      theme(plot.title = element_text(size = 18, hjust = 0.5))
  })
  
}

# Run the app ----
shinyApp(ui = ui, server = server)  # Aggregates the app.